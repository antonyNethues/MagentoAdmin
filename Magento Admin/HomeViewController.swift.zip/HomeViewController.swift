//
//  HomeViewController.swift
//  Magento Admin
//
//  Created by Lokesh Gupta on 30/08/17.
//  Copyright © 2017 Lokesh Gupta. All rights reserved.
//

import UIKit

class HomeViewController: SlideMenuController,UITabBarDelegate,SlideMenuControllerDelegate {

    @IBOutlet var upperViewContainer: UIView!
    @IBOutlet var customTabBar: UITabBar!
    var boolVal = Int()

    var shadowViewCont : UIViewController!
    var bgView = UIView()
    var bgView2 = UIView()
    var bgView3 = UIView()
    var bgView4 = UIView()
    var bgView5 = UIView()
    
    @IBOutlet var orderItem: UITabBarItem!
    @IBOutlet var customerItem: UITabBarItem!
    @IBOutlet var productItem: UITabBarItem!
    @IBOutlet var CategoryItem: UITabBarItem!
    @IBOutlet var dashboardItem: UITabBarItem!
    var viewController1: UITabBarController?
    var viewController2_1: UITabBarController?
    var viewController2: UITabBarController?
    var viewController3: UITabBarController?
    var viewController4: UITabBarController?
    
    var imagesArr = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.delegate = self
        self.customTabBar.delegate = self
        // Do any additional setup after loading the view.
        
        if let controller = self.storyboard?.instantiateViewController(withIdentifier: "Right") {
            self.rightViewController = controller
        }
        DispatchQueue.main.async(execute: { () -> Void in
            self.tabBar(self.customTabBar, didSelect: self.dashboardItem)
            self.customTabBar.selectedItem = self.dashboardItem
        })
        
        self.customTabBar.backgroundColor = ObjRef.sharedInstance.magentoOrange
        self.customTabBar.isTranslucent = true
        self.customTabBar.isOpaque = false
        self.customTabBar.barTintColor = ObjRef.sharedInstance.magentoOrange
        //self.customTabBar.tintColor = UIColor.lightGray
        
        let normalTitleFont = UIFont.systemFont(ofSize: 12, weight: UIFontWeightRegular)

        UITabBarItem.appearance().setTitleTextAttributes([NSFontAttributeName:normalTitleFont], for: .normal)

        let layerGradient = CAGradientLayer()
        layerGradient.colors = [UIColor(red: 0, green: 0, blue: 0, alpha: 0.2).cgColor,UIColor.clear.cgColor,UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor, UIColor(red: 0, green: 0, blue: 0, alpha: 0.2).cgColor]
        
        layerGradient.startPoint = CGPoint(x: 0, y: 0.1)
        layerGradient.endPoint = CGPoint(x: 0, y:0.9 )
        layerGradient.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.customTabBar.frame.size.height)
        self.customTabBar.layer.insertSublayer(layerGradient, at: 0)
        
        
        
        let itemWidth = self.customTabBar.frame.width / CGFloat(self.customTabBar.items!.count)
        bgView = UIView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: customTabBar.frame.height))
        bgView.backgroundColor = UIColor(red: 249/255.0, green: 91/255.0, blue: 33/255.0, alpha: 1.0)
        self.customTabBar.insertSubview(bgView, at: 1)

        bgView2 = UIView(frame: CGRect(x: itemWidth*1, y: 0, width: itemWidth, height: customTabBar.frame.height))
        bgView2.backgroundColor = UIColor(red: 249/255.0, green: 91/255.0, blue: 33/255.0, alpha: 1.0)
        self.customTabBar.insertSubview(bgView2, at: 1)

        bgView3 = UIView(frame: CGRect(x: itemWidth*2, y: 0, width: itemWidth, height: customTabBar.frame.height))
        bgView3.backgroundColor = UIColor(red: 249/255.0, green: 91/255.0, blue: 33/255.0, alpha: 1.0)
        self.customTabBar.insertSubview(bgView3, at: 1)

        bgView4 = UIView(frame: CGRect(x: itemWidth*3, y: 0, width: itemWidth, height: customTabBar.frame.height))
        bgView4.backgroundColor = UIColor(red: 249/255.0, green: 91/255.0, blue: 33/255.0, alpha: 1.0)
        self.customTabBar.insertSubview(bgView4, at: 1)

        bgView5 = UIView(frame: CGRect(x: itemWidth*4, y: 0, width: itemWidth, height: customTabBar.frame.height))
        bgView5.backgroundColor = UIColor(red: 249/255.0, green: 91/255.0, blue: 33/255.0, alpha: 1.0)
        self.customTabBar.insertSubview(bgView5, at: 1)

        
        
        //title color of tabbar
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.white,NSFontAttributeName: UIFont.boldSystemFont(ofSize: (self.view.frame.size.width/320)*9)], for:.normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.white,NSFontAttributeName: UIFont.boldSystemFont(ofSize: (self.view.frame.size.width/320)*9)], for:.selected)
        
    }
    
    func changeColorOfButton(view : UIView) {
        
        bgView.backgroundColor = UIColor.clear
        bgView2.backgroundColor = UIColor.clear
        bgView3.backgroundColor = UIColor.clear
        bgView4.backgroundColor = UIColor.clear
        bgView5.backgroundColor = UIColor.clear

        view.backgroundColor = ObjRef.sharedInstance.magentoOrange
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.customTabBar.isTranslucent = false
        //self.navigationController?.navigationBar.isHidden = true
        UITabBar.appearance().tintColor = UIColor.red
        imagesArr = ["dashboard.png","products-list.png","category.png","customer.png","order.png"]

        if let items = self.customTabBar.items {
            var tabBarImages = UIImage(named: "search") // tabBarImages: [UIImage]
            
            for i in 0..<items.count {
                let imageName = imagesArr.object(at: i) as! String

                   // tabBarImages = UIImage(named: imageName) // tabBarImages: [UIImage]

                let tabBarItem = items[i]
                let tabBarImage = tabBarImages
                tabBarItem.image = tabBarImage?.withRenderingMode(.alwaysOriginal)
                tabBarItem.selectedImage = tabBarImage
            }
        }
    }

    func MenuTapped(_ sender: Any) {
        if self.slideMenuController()?.menuIsOpen == false {
            //boolVal = 1
            self.slideMenuController()?.openRight()
        }
        else {
           // boolVal = 0
            self.slideMenuController()?.closeRight()
        }
    }
   
    func rightDidOpen() {
        if shadowViewCont == nil {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            shadowViewCont = storyboard.instantiateViewController(withIdentifier: "ShadowViewCont") 
            self.addChildViewController(shadowViewCont)
            
        }
        
        self.view.insertSubview(shadowViewCont!.view!, belowSubview: self.customTabBar)

    }
    func rightDidClose() {
        shadowViewCont.view.removeFromSuperview()
        //self.tabBar(self.customTabBar, didSelect: self.customTabBar.selectedItem!)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        
        switch item.tag {
            
        case 1:
            if viewController1 == nil {
                
                var storyboard = UIStoryboard(name: "Main", bundle: nil)
                viewController1 = storyboard.instantiateViewController(withIdentifier: "ViewController1") as! UITabBarController
                self.addChildViewController(viewController1!)

            }
            if self.rightViewController != nil {
                (self.rightViewController as! RightViewController).indexSelected = 0
                if (self.rightViewController as! RightViewController).menuTableView != nil {
                    (self.rightViewController as! RightViewController).menuTableView.reloadData()
                }
            }
            
            self.changeColorOfButton(view: self.bgView)
            //ShadowViewCont
            self.view.insertSubview(viewController1!.view!, belowSubview: self.customTabBar)
            break
            
            
        case 2:
            if viewController2_1 == nil {
                
                var storyboard = UIStoryboard(name: "Main", bundle: nil)
                viewController2_1 = storyboard.instantiateViewController(withIdentifier: "viewController2_1") as! UITabBarController
                self.addChildViewController(viewController2_1!)
            }
            if self.rightViewController != nil {
                (self.rightViewController as! RightViewController).indexSelected = 1
                if (self.rightViewController as! RightViewController).menuTableView != nil {
                    (self.rightViewController as! RightViewController).menuTableView.reloadData()
                }
            }
            self.changeColorOfButton(view: self.bgView2)

            self.view.insertSubview(viewController2_1!.view!, belowSubview: self.customTabBar)
            break
            
        case 3:
            if viewController2 == nil {
                
                var storyboard = UIStoryboard(name: "Main", bundle: nil)
                viewController2 = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! UITabBarController
                self.addChildViewController(viewController2!)
            }
            if self.rightViewController != nil {
                (self.rightViewController as! RightViewController).indexSelected = 2
                if (self.rightViewController as! RightViewController).menuTableView != nil {
                    (self.rightViewController as! RightViewController).menuTableView.reloadData()
                }
            }
            
            self.changeColorOfButton(view: self.bgView3)

            self.view.insertSubview(viewController2!.view!, belowSubview: self.customTabBar)
            break
            
        case 4:
            if viewController3 == nil {
                
                var storyboard = UIStoryboard(name: "Main", bundle: nil)
                viewController3 = storyboard.instantiateViewController(withIdentifier: "ViewController3") as! UITabBarController
                self.addChildViewController(viewController3!)
                
            }
            if self.rightViewController != nil {
                (self.rightViewController as! RightViewController).indexSelected = 4
                if (self.rightViewController as! RightViewController).menuTableView != nil {
                    (self.rightViewController as! RightViewController).menuTableView.reloadData()
                }
            }
            
            self.changeColorOfButton(view: self.bgView4)

            self.view.insertSubview(viewController3!.view!, belowSubview: self.customTabBar)
            break
            
        case 5:
            if viewController4 == nil {
                
                var storyboard = UIStoryboard(name: "Main", bundle: nil)
                viewController4 = storyboard.instantiateViewController(withIdentifier: "ViewController4") as! UITabBarController
                self.addChildViewController(viewController4!)
                
            }
            if self.rightViewController != nil {
                (self.rightViewController as! RightViewController).indexSelected = 5
                if (self.rightViewController as! RightViewController).menuTableView != nil {
                    (self.rightViewController as! RightViewController).menuTableView.reloadData()
                }
            }
            
            self.changeColorOfButton(view: self.bgView5)

            self.view.insertSubview(viewController4!.view!, belowSubview: self.customTabBar)
            break
            
        default:
            break
            
        }
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
