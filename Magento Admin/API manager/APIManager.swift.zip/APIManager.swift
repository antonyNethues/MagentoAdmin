//
//  APIManager.swift
//  Magento Admin
//
//  Created by Lokesh Gupta on 23/08/17.
//  Copyright © 2017 Lokesh Gupta. All rights reserved.
//

import UIKit

class APIManager: NSObject {

    
    let baseURL = "https://httpbin.org/get"//"https://jsonplaceholder.typicode.com"
    static let sharedInstance = APIManager()
    static let getPostsEndpoint = "/posts/"

    
    
    func getPostWithId(postId: Int, onSuccess: @escaping(JSON) -> Void, onFailure: @escaping(Error) -> Void){
        /*
 
 let url: NSURL = NSURL(string: APIBaseURL + "&login=1951&pass=1234")!
 var params = ["login":"1951", "pass":"1234"]
 request = NSMutableURLRequest(URL:url)
 request.HTTPMethod = "POST"
 var err: NSError?
 request.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: nil, error: &err)
 request.addValue("application/json", forHTTPHeaderField: "Content-Type")
 request.addValue("application/json", forHTTPHeaderField: "Accept")
 
 */
     
        /*
 
 let headers = [
 "content-type": "application/json",
 "cache-control": "no-cache",
 "postman-token": "66df587c-262f-27a6-79fc-94b4b6dc7537"
 ]
 let parameters = [
 "username": "antony2@a.com",
 "password": "12345"
 ] as [String : Any]
 
 let postData = JSONSerialization.data(withJSONObject: parameters, options: [])
 
 let request = NSMutableURLRequest(url: NSURL(string: "https://www.fibodo.com/testing/api/v2.5/login")! as URL,
 cachePolicy: .useProtocolCachePolicy,
 timeoutInterval: 10.0)
 request.httpMethod = "POST"
 request.allHTTPHeaderFields = headers
 request.httpBody = postData as Data
 
 let session = URLSession.shared
 let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
 if (error != nil) {
 print(error)
 } else {
 let httpResponse = response as? HTTPURLResponse
 print(httpResponse)
 }
 })
 
 dataTask.resume()
 
 */
        //let url : String = baseURL + APIManager.getPostsEndpoint + String(postId)
        let url : String = baseURL
        let request: NSMutableURLRequest = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "GET"
        //request.allHTTPHeaderFields = ["adf": "GL_DRAW_BUFFER0","adf": "GL_DRAW_BUFFER0"]
       // request.setValue("Client-ID <your_client_id>", forHTTPHeaderField: "Authorization")

        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest, completionHandler: {data, response, error -> Void in
            if(error != nil){
                onFailure(error!)
            } else{
                do {
                let result = try JSON(data: data!)
                onSuccess(result)
                }
                catch {
                    onFailure(error)
                }
            }
        })
        task.resume()
    }
}
